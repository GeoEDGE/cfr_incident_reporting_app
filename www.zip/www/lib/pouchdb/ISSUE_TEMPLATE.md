<!--
     Hello! 👋
     Thank you for opening an issue on PouchDB.
     This template is optional, but it may help us fix your issue faster.
-->

### Environment (Node.js/browser/hybrid app/etc.)

(Write here.)

### Browser/platform (Chrome/FF/Safari/Edge/iOS/Android/etc.)

(Write here.)

### Adapter (IndexedDB/WebSQL/LevelDB/etc.)

(Write here.)

### Server (CouchDB/Cloudant/Couchbase/PouchDB Server/etc.)

(Write here.)

### Please describe your issue. Test cases (e.g. JSBin) are very helpful!

(Write here.)
