(function() {

    var app = angular.module('queup', ['ionic', 'ngCordova']);

    app.config(function($stateProvider, $urlRouterProvider) {
        $stateProvider.state('queue', {
            url: '/queue',
            templateUrl: 'templates/queue.html'
        });
        $stateProvider.state('edit', {
            url: '/edit',
            templateUrl: 'templates/edit.html'
        });

        $urlRouterProvider.otherwise('/queue');
    });


    app.controller('QueueController', function($scope) {
        $scope.queue = [{
            name: ' ',
            status: 'waiting in queue'
        }, {
            name: ' ',
            status: 'waiting in queue'
        }];
    });

  app.controller('QueueController', ['$scope', '$rootScope', '$cordovaCamera', function($scope, $rootScope, $cordovaCamera){

    $scope.ready = false;
    $scope.images = [];

    $rootScope.$watch('appReady.status', function() {
      console.log('watch fired '+$rootScope.appReady.status);
      if($rootScope.appReady.status) $scope.ready = true;
    });
    //gallery
    $scope.choosePhoto = function() {

      window.imagePicker.getPictures(
        function(results) {
          for (var i = 0; i < results.length; i++) {
            console.log('Image URI: ' + results[i]);
            $scope.images.push(results[i]);
          }
          if(!$scope.$$phase) {
            $scope.$apply();
          }
        }, function (error) {
          console.log('Error: ' + error);
        }
      );

    };


      $scope.takePhoto = function () {
          var options = {
              quality: 75,
              destinationType: Camera.DestinationType.DATA_URL,
              sourceType: Camera.PictureSourceType.CAMERA,
              allowEdit: true,
              encodingType: Camera.EncodingType.JPEG,
              targetWidth: 300,
              targetHeight: 300,
              popoverOptions: CameraPopoverOptions,
              saveToPhotoAlbum: true
          };

          $cordovaCamera.getPicture(options).then(function (imageData) {
              $scope.srcImage = "data:image/jpeg;base64," + imageData;
          }, function (err) {
              // An error occured. Show a message to the user
          });
  };

      $scope.gpsTest=function(){

      var onSuccess = function (position) {
              alert('Latitude: ' + position.coords.latitude + '\n' +
                    'Longitude: ' + position.coords.longitude + '\n' +
                    'Altitude: ' + position.coords.altitude + '\n' +
                    'Accuracy: ' + position.coords.accuracy + '\n' +
                    'Altitude Accuracy: ' + position.coords.altitudeAccuracy + '\n' +
                    'Heading: ' + position.coords.heading + '\n' +
                    'Speed: ' + position.coords.speed + '\n' +
                    'Timestamp: ' + position.timestamp + '\n');
          };

          // onError Callback receives a PositionError object

            if (window.cordova) {
                cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
                    alert("Location is " + (enabled ? "enabled" : "disabled"));
                    cordova.plugins.diagnostic.switchToLocationSettings();
                }, function(error) {
                    alert("The following error occurred: " + error);
                });
            }
              alert('code: ' + error.code + '\n' +
                    'message: ' + error.message + '\n');


          navigator.geolocation.getCurrentPosition(onSuccess, onError);
    };


}])

    app.module("discription", [])
        .controller('ExampleController', ['$scope', function($scope) {

            $scope.data.discription = ""

        }])

    app.module("address", [])
        .controller('ExampleController', ['$scope', function($scope) {

            $scope.data.address = ""

        }]);

    app.module("name", [])
        .controller('ExampleController', ['$scope', function($scope) {

            $scope.data.name = ""

        }]);

    app.module("contactno", [])
        .controller('ExampleController', ['$scope', function($scope) {

            $scope.data.contactno = ""

        }]);

    app.run(function($ionicPlatform) {
        $ionicPlatform.ready(function() {
            if (window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);
            }
            if (window.StatusBar) {
                StatusBar.styleDefault();
            }
            try {

               } catch (error) {
                   alert(error);
               }



        });
    });


/*     app.controller("ExampleController", function($scope, $cordovaSQLite) {

    $scope.save = function() {
        var query = "INSERT INTO Incident (latitude,longitude,disasterType,description,name,contactNo,reportedDateTime,locationName) VALUES (6.98, 79.8, 1, 'Test', 'sachie',0788550013,2007-01-01 10:00:00,'Nawala')";
        $cordovaSQLite.execute(db, query).then(function(res) {
            alert("done");
        }, function (err) {
            console.error(err);
        });
    }

    $scope.load = function() {
        var query = "SELECT * FROM Incident";
        $cordovaSQLite.execute(db, query).then(function(res) {
            if(res.rows.length > 0) {
                alert("done");
            } else {
                  alert(" not done");
            }
        }, function (err) {
            console.error(err);
        });
    }

});*/


})();
